<?php $connection=mysqli_connect('localhost','mirza','mirza016','electrodule'); ?>
<!DOCTYPE html>
<html>
<style >
  .top {
  background-image: url("location.png");
  height: 100%;
  width: 45%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.text {
  padding: 5px;
  text-align: center;
  color:black;
  font-size: 10px;
}
.text1 {
  text-align:center;
  color:black;
  font-size: 50px;
}
.button {
  border: none;
  color:teal;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
.button1 {
  background-color:#04AA6D; 
  color: black; 
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color:darkseagreen;
  color:green;
}
.button2 {
  background-color:Turquoise; 
  color: black; 
  border: 2px solid #4CAF50;
  padding: 15px;
}

.button2:hover {
  background-color:darkseagreen;
  color:green;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
.row1:after {
  content: "";
  display: table;
  clear: both;
  width: 250%;
}
.col-75 {
  float: left;
  width:90%;
  margin-top: 60px;
}
</style>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ElectroDule</title>
</head>
<body class="top">
<div class="text">
  <form action="" method="POST">
    <div class="row">
  <div class="col-75">
      <select  name="location">
        <option value="Azimpur">Azimpur</option>
        <option value="Banani">Banani</option>
        <option value="Basabo">Basabo</option>
        <option value="Demra">Demra</option>
        <option value="Dhaka cantt.">Dhaka cantt.</option>
        <option value="Jigatala">Jigatala</option>
        <option value="Gulshan">Gulshan</option>
        <option value="Banani">Banani</option>
        <option value="Keraniganj">Keraniganj</option>
        <option value="Khilgaon">Khilgaon</option>
        <option value="Mohammadpur">Mohammadpur</option>
        <option value="Motizeel">Motizeel</option>
        <option value="Nawabganj">Nawabganj</option>
        <option value="Paltan">Paltan</option>
        <option value="Shantinagar">Shantinagar</option>
        <option value="Basabo">Basabo</option>
        <option value="Savar">Savar</option>
        <option value="Tejgaon">Tejgaon</option>
        <option value="Uttara">Uttara</option>
        <option value="Khilkhet">Khilkhet</option>
        <option value="Lalbhag">Lalbhag</option>
        <option value="Hasnabad">Hasnabad</option>
      </select>
    </div>
    </div>
  <input type="submit" name="submit" value="Search">
  </form>
</div>
<div>
  <?php
  $Loc="Not Selected Yet";
  $Zip="Not Selected Yet";
  $Time="Not Selected Yet";
  if(isset($_POST['submit'])){
    $loc=$_POST['location'];
    $sql="SELECT t.l_name,l.zip,t.time_am
         FROM _time t LEFT JOIN locations l
         ON(t.l_name=l.l_name)
         WHERE l.l_name LIKE '$loc' ";

    $res=mysqli_query($connection, $sql);

    if($res){
      $data=mysqli_fetch_assoc($res);

      $Loc=$data['l_name'];
      $Zip=$data['zip'];
      $Time=$data['time_am'];

      mysqli_close($connection);
    }
    elseif (is_null($res)){
      echo "not created any schedule";
    }

}
?>
<p class="text1">Location: <?php echo $Loc; ?></P>
<p class="text1">Zip: <?php echo $Zip ?></p>
<p class="text1">Time: <?php echo $Time ?></p>
</div>
<button class="button button1"><a href="dpdc_admin_choose_operation.php">Previous</a></button>
<button class="button button2"><a href="update_schedule.php">Update Time</a></button>
</body>
</html>
