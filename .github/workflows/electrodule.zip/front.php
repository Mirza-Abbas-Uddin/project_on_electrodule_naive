<!DOCTYPE html>
<html>
<title>ElectroDule</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
  height: 100%;
  margin: 0;
  background-color: white;
}
.text {
  padding: 30px;
  text-align: left;
  color:white;
  font-size: 30px;
}
.text1 {
  color: white;
  font-size: 40px;
  font-style: italic;
}
.text2 {
  color:black;
  font-size: 40px;
  font-style: italic;
}
.text3 {
  padding: 5px;
  text-align: left;
  color:gray;
  font-size: 30px;
}
.bottom {
  padding: 30px;
  text-align: center;
  color: black;
  font-size: 30px;
}
.bottom1 {
  padding: 30px;
  text-align: center;
  background-color: green;
  color: greenyellow;
  font-size: 30px;
}
.bottom2 {
  padding: 30px;
  text-align: center;
  background-color: darkorange;
  color:green;
  font-size: 30px;
}
.top {
  background-image: url("front4.jpg");
  height: 100%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.btn{
  background-color: #04AA6D;
 color: white;
 font-size: 30px;
 margin: auto;
 margin-bottom: auto;
 display: block;
 width: 200px;
 border-radius: 10px;
}
</style>
</head>
<body>

<div class="top">
  <div class="text">
    <h1>Welcome to ElectroDule</h1>
    <p class="text3">Save Time Live Life</p>
  </div>
</div>


<div class="bottom">
  <h2>Login as</h2>
  <a class="btn" href="user_login.php" style="margin-bottom:5px;">User</a>
  <p>  </p>
  <a class="btn" href="admin_select_company.php" style="margin-bottom:5px;">Admin</a>
</div>
<div class="bottom1">
  <h2>How it works</h2>
  <p class="text1">This website will notify you with the schedule of load-shedding in your area and you can also see your electric bill through it!</p>
  <p class="text1">Besides,employees of the distributing companies will be upto date in their management!</p>
</div>
<div class="bottom2">
  <h2>Our Mission</h2>
  <p class="text2">We cannot solve the load shedding problem but if we can make a system where the common
people will get to know when load shedding will occur, people will able to manage their time
efficiently. By that we will be to save our time from idleness as well as it would be very helpful
for the students.</p>
</div>
</body>
</html>
