<!DOCTYPE html>
<html>
<title>ElectroDule</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
  height: 100%;
  margin: 0;
  background-color: white;
}
.text {
  padding: 100px;
  text-align: center;
  color: black;
  font-size: 40px;
}
.top {
  background-image: url("admin-select-company1.jpg");
  height: 100%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.btn{
  background-color:darkred; !important;
 color: white;
 font-size: 18px;
 margin: auto;
 margin-bottom: auto;
 display:block;
 line-height: 3;
 width: 200px;
 border-radius: 25px;
}
.btn1{
 background-color:green !important;
 color: white;
 font-size: 18px;
 margin: auto;
 margin-bottom: auto;
 display:block;
 line-height: 3;
 width: 200px;
 border-radius: 25px;
}
</style>
</head>
<body>

<div class="top">
  <div class="text">
   <p>Select Your Company</p>
   <a class="btn" href="dpdc_login_page.php" style="margin-bottom:5px;">DPDC</a>
   <p>  </p>
   <a class="btn1" href="desco_login_page.php" style="margin-bottom:5px;">DESCO</a>
  </div>
</div>

</body>
</html>
