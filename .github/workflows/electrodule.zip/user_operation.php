<?php
session_start();
echo "User Profile:".$_SESSION['user_name'];

 ?>