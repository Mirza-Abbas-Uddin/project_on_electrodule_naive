

<!DOCTYPE html>
<html>
<title>ElectroDule</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
  height: 100%;
  margin: 0;
  background-color: white;
}
.center {
  padding: 20px;
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 20%;
}
.text1 {
  padding: 120px;
  text-align: center;
  color: black;
  font-size: 40px;
  font-style: italic;
}
.btn{
  background-color: #4CAF50; /* Green */
  border-radius: 50%;
  color: white;
  padding: 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 25px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
</head>
<body>

<div>
   <img src="Success.png" alt="Successful" class="center"> 
  <p class="text1">Congratulations, Your account has been successfully created.<br><br>
  <a class="btn" href="dpdc_login_page.php" style="margin-bottom:5px;">Continue</a>
   </p>
</div>  
</body>
</html>
