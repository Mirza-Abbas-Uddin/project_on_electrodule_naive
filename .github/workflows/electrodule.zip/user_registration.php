<?php 
   
   $connection=mysqli_connect('localhost','mirza','mirza016','electrodule');

   if(!$connection){
    echo "Not Connected";
   }
  $error = array('user_name'=>'','password'=>'','location'=>'','zip'=>'','email'=>'');
  if(isset($_POST['submit'])){
    if(isset($_POST['submit'])){
    if(empty($_POST['user_name'])){
      echo "An username is required.<br>";
    }
  }
    else{
      $UserName=$_POST['user_name'];
      echo htmlspecialchars($_POST['user_name']);
    }
    if(empty($_POST['password'])){
      echo "A password is required.<br>";
    }
    else{
      $Password=$_POST['password'];
      echo htmlspecialchars($_POST['password']);
    }
    if(empty($_POST['location'])){
      echo "Please,submit your location.<br>";
    }
    else{
      $Location=$_POST['location'];
      echo htmlspecialchars($_POST['location']);
    }
    if(empty($_POST['zip'])){
      echo "Enter the ZIP code.<br>";
    }
    else{
      $ZIP=$_POST['zip'];
      echo htmlspecialchars($_POST['zip']);
    }
    if(empty($_POST['email'])){
      echo "An email is required.<br>"; 
    }
    else{
      $Email=$_POST['email'];
      if(!filter_var($Email,FILTER_VALIDATE_EMAIL)){
        $desco['email']="Invalid email type";
      }
      else{
        echo htmlspecialchars($_POST['email']);
      }
    }

    if(array_filter($error)){
      echo "Error in the form.<br>";
    }
    else{
      $UserName=mysqli_real_escape_string($connection,$_POST['user_name']);
      $Password=mysqli_real_escape_string($connection,$_POST['password']);
      $Location=mysqli_real_escape_string($connection,$_POST['location']);
      $ZIP=mysqli_real_escape_string($connection,$_POST['zip']);
      $Email=mysqli_real_escape_string($connection,$_POST['email']);

      //$sql="INSERT INTO `dpdc_admin`(`username`, `password`, `location`, `zip`, `email`) VALUES ('$UserName','$Password','$Location','$ZIP','$Email')";

      $sql="INSERT INTO `_user`(`username`, `password`, `location`, `zip`, `email`) VALUES ('$UserName','$Password','$Location','$ZIP','$Email')";

      if(mysqli_query($connection,$sql)){
        header('Location:user_login.php');
      }
      else{
        echo "Error";
      }
    }
  }
 ?>
 
 <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>ElectroDule</title>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}

.icon {
  padding: 10px;
  background: dodgerblue;
  color: white;
  min-width: 50px;
  text-align: center;
}
.input-field {
  width: 100%;
  padding: 10px;
  outline: none;
}

.input-field:focus {
  border: 2px solid dodgerblue;
}

/* Set a style for the submit button */
.btn {
  background-color: dodgerblue;
  color: white;
  padding: 15px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
input[type="date"]::-webkit-calendar-picker-indicator {
    background: transparent;
    bottom: 0;
    color: transparent;
    cursor: pointer;
    height: auto;
    left: 0;
    position: absolute;
    right: 0;
    top: 0;
    width: auto;
}
</style>
</head>
<body>

<form action="user_registration.php" method="POST" style="max-width:500px;margin:auto">
  <h2>Registration Form</h2>
  <div class="input-container">
    <i class="fa fa-user icon"></i>
    <input class="input-field" type="text" name="user_name" placeholder="Username">
    <div class="red-text"><?php echo $error['user_name']; ?></div>
  </div>
  <div class="input-container">
    <i class="fa fa-key icon"></i>
    <input class="input-field" type="password" name="password" placeholder="Password">
    <div class="red-text"><?php echo $error['password']; ?></div>
  </div>
  <div class="input-container">
    <i class="fa fa-map-marker icon"></i>
    <input class="input-field" type="text" name="location" placeholder="Location">
    <div class="red-text"><?php echo $error['location']; ?></div>
  </div>
  <div class="input-container">
    <i class="fa fa-file-zip-o icon"></i>
    <input class="input-field" type="text" name="zip" placeholder="Zip code">
    <div class="red-text"><?php echo $error['zip']; ?></div>
  </div>
  <div class="input-container">
    <i class="fa fa-envelope icon"></i>
    <input class="input-field" type="text" name="email" placeholder="Email">
    <div class="red-text"><?php echo $error['email']; ?></div>
  </div>
  <button type="submit" name ="submit" value="submit" class="btn">Register</button>
</form>

</body>
</html>