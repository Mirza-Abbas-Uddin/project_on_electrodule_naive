<?php 
     session_start();
     echo "User Profile: ".$_SESSION['user_name'];
 ?>
<html>
<head>
<title>ElectroDule</title>
<style>
.text {
  padding: 30px;
  text-align:center;
  color:indigo;
  font-size: 30px;
}
.button {
  background-color: #4CAF50; /* Green */
  width: 100%;
  height: 20%;
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: lime; 
  color: black; 
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color:darkgreen;
  color: white;
}

.button2 {
  background-color:darksalmon; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: darkgreen;
  color: white;
}

.button3 {
  background-color: darkviolet; 
  color: black; 
  border: 2px solid #f44336;
}

.button3:hover {
  background-color:darkgreen;
  color: white;
}

.button4 {
  background-color:SlateBlue;
  color: black;
  border: 2px solid #e7e7e7;
}

.button4:hover {background-color:darkgreen;}

.button5 {
  background-color: Gray;
  color: dimgray;
  border: 2px solid #555555;
}

.button5:hover {
  background-color: greenyellow;
  color: greenyellow;
}
</style>
</head>
<body>

<h2 class="text">Select Your Operation</h2>

<button class="button button2"> <a href="create_schedule.php">Create Schedule</a> </button>
<button class="button button1"><a href="show_schedule.php">Show Schedule</a></button>
<button class="button button3"><a href="update_schedule.php">Update Schedule</a></button>
<button class="button button4"><a href="delete_schedule.php">Delete Schedule</a></button>
<button class="button button5"><a href="front.php">Logout</a></button>
</body>
</html>