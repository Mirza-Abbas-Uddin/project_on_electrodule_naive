<?php $connection=mysqli_connect('localhost','mirza','mirza016','electrodule'); ?>
<!DOCTYPE html>
<html>
<head>
 
<style>
* {
  box-sizing: border-box;
}
.top {
  background-image: url("delete2.jpg");
  height: 100%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
  height: 50%;
}

input[type=submit]:hover {
  background-color: #45a049;
}
.text {
  padding: 3px;
  text-align: center;
  color:black;
  font-size: 30px;
}
.text1 {
  padding: 10px;
  text-align: center;
  color:black;
  font-size: 20px;
}
.text3 {
  height: 50%;
  position:!important;
  width: 30%;
  padding: 3px;
  text-align: center;
  color:black;
  font-size: 20px;
}
.text4 {
  position:!important;
  padding: 100px;
  float:left;
  color:black;
  font-size: 20px;
}
.text5 {
	padding: 25px;
    left: 50%;
    top: 60%;
    margin-left: -25%;
    position: absolute;
    margin-top: -25%;
}
.text6 {
  width: 30%;
  position:!important;
  padding: 180px;
  float:left;
  color:black;
  font-size: 15px;
}
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 10%;
  margin-top: 10px;
}
.button {
  border: none;
  color:teal;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 350px 2px;
  transition-duration: 0.4s;
  cursor: pointer;

}
.button1 {
  background-color:blueviolet; 
  color: black; 
  border: 2px solid #4CAF50;
  padding: 15px;
}

.button1:hover {
  background-color:darkseagreen;
  color:green;
}
.button2 {
  background-color:SteelBlue; 
  color: black; 
  border: 2px solid #4CAF50;
  padding: 15px;
}

.button2:hover {
  background-color:darkseagreen;
  color:green;
}
.col-75 {
  float: left;
  width:90%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
.row1:after {
  content: "";
  display: table;
  clear: both;
  width: 25%;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 300px) {
  .col-25, .col-75, input[type=submit] {
    width: 70%;
    margin-top: 0;
  }
}
</style>
</head>
<script type='text/javascript'>alert('Location will be deleted with time');</script>
<body class="top">
<h2 class="text">Select The Location</h2>

<div class="center">
  <form action="" method="POST">
  <div class="row">
    <div class="col-25">
      <label for="loc">Location:</label>
    </div>
    <div class="col-75">
      <select  name="loc">
        <option value="Azimpur">Azimpur</option>
        <option value="Banani">Banani</option>
        <option value="Basabo">Basabo</option>
        <option value="Demra">Demra</option>
        <option value="Dhaka cantt.">Dhaka cantt.</option>
        <option value="Jigatala">Jigatala</option>
        <option value="Gulshan">Gulshan</option>
        <option value="Banani">Banani</option>
        <option value="Keraniganj">Keraniganj</option>
        <option value="Khilgaon">Khilgaon</option>
        <option value="Mohammadpur">Mohammadpur</option>
        <option value="Motizeel">Motizeel</option>
        <option value="Nawabganj">Nawabganj</option>
        <option value="Paltan">Paltan</option>
        <option value="Shantinagar">Shantinagar</option>
        <option value="Basabo">Basabo</option>
        <option value="Savar">Savar</option>
        <option value="Tejgaon">Tejgaon</option>
        <option value="Uttara">Uttara</option>
        <option value="Khilkhet">Khilkhet</option>
        <option value="Lalbhag">Lalbhag</option>
        <option value="Hasnabad">Hasnabad</option>
      </select>
    </div>
  </div>
  <br>
  <div class="row">
    <input type="submit" name="submit" value="Delete">
  </div>
  </form>
</div>
</div>
<button class="button button1"><a href="dpdc_admin_choose_operation.php">Previous</a></button>
<button class="button button2"><a href="create_schedule.php">Create Schedule</a></button>
</body>
</html>


<?php 
if (isset($_POST['submit'])) {
  if(!empty($_POST['loc']))
  {
     $Loc=$_POST['loc'];

     $select_sql="SELECT `l_name` FROM `_time` WHERE l_name LIKE '$Loc' ";
     $res=mysqli_query($connection, $select_sql);
     $data=mysqli_fetch_assoc($res);
     $C_Loc=$data['l_name'];
     if(!is_null($C_Loc))
     {
       $sql="DELETE FROM `_time` WHERE l_name LIKE '$Loc' ";
        if(mysqli_query($connection,$sql)){
          echo '<script type="text/javascript">';
          echo ' alert("Record deleted successfully")';  //not showing an alert box.
          echo '</script>';
         }
     
        else{
           echo "Error deleting record: " . $connection->error_log("select the location carefylly");
         }
     }
     else
     {
       echo "Error deleting record: " . $connection->error_log("Location might deleted earliar");
     }
     
     
  }
}
?>

